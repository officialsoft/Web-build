
const listings = [
  {
    "id": "H-R-201",
    "title": "1-Bedroom Bungalow, Karu",
    "location": "Karu",
    "category": "rent",
    "price": "₦1,050,491",
    "priceNote": "per year",
    "specs": [
      "1 bed",
      "1 bath",
      "101 sqm"
    ],
    "image": "h2.jpeg"
  },
  {
    "id": "H-R-202",
    "title": "1-Bedroom Self-Contain, Wuse 2",
    "location": "Wuse 2",
    "category": "rent",
    "price": "₦8,623,502",
    "priceNote": "per year",
    "specs": [
      "1 bed",
      "1 bath",
      "131 sqm"
    ],
    "image": "h1.jpeg"
  },
  {
    "id": "H-R-203",
    "title": "4-Bedroom Bungalow, Gwarinpa",
    "location": "Gwarinpa",
    "category": "rent",
    "price": "₦4,087,621",
    "priceNote": "per year",
    "specs": [
      "4 bed",
      "3 bath",
      "157 sqm"
    ],
    "image": "h3.jpeg"
  },
  {
    "id": "H-R-204",
    "title": "2-Bedroom Flat, Victoria Island",
    "location": "Victoria Island",
    "category": "rent",
    "price": "₦7,423,547",
    "priceNote": "per year",
    "specs": [
      "2 bed",
      "2 bath",
      "128 sqm"
    ],
    "image": "h4.jpeg"
  },
  {
    "id": "H-R-205",
    "title": "2-Bedroom Duplex, Maryland",
    "location": "Maryland",
    "category": "rent",
    "price": "₦3,472,150",
    "priceNote": "per year",
    "specs": [
      "2 bed",
      "2 bath",
      "113 sqm"
    ],
    "image": "h6.jpeg"
  },
  {
    "id": "H-R-206",
    "title": "1-Bedroom Duplex, Magodo",
    "location": "Magodo",
    "category": "rent",
    "price": "₦4,802,756",
    "priceNote": "per year",
    "specs": [
      "1 bed",
      "1 bath",
      "94 sqm"
    ],
    "image": "h5.jpeg"
  },
  {
    "id": "H-R-207",
    "title": "2-Bedroom Terrace, Maitama",
    "location": "Maitama",
    "category": "rent",
    "price": "₦3,775,124",
    "priceNote": "per year",
    "specs": [
      "2 bed",
      "2 bath",
      "38 sqm"
    ],
    "image": "h7.jpeg"
  },
  {
    "id": "H-R-208",
    "title": "4-Bedroom Terrace, Lugbe",
    "location": "Lugbe",
    "category": "rent",
    "price": "₦2,687,506",
    "priceNote": "per year",
    "specs": [
      "4 bed",
      "3 bath",
      "94 sqm"
    ],
    "image": "images (21).jpeg"
  },
  {
    "id": "H-R-209",
    "title": "3-Bedroom Self-Contain, Kaduna GRA, Kaduna",
    "location": "Kaduna GRA, Kaduna",
    "category": "rent",
    "price": "₦899,383",
    "priceNote": "per year",
    "specs": [
      "3 bed",
      "3 bath",
      "78 sqm"
    ],
    "image": "images (22).jpeg"
  },
  {
    "id": "H-R-210",
    "title": "2-Bedroom Terrace, Bompai, Kano",
    "location": "Bompai, Kano",
    "category": "rent",
    "price": "₦1,188,870",
    "priceNote": "per year",
    "specs": [
      "2 bed",
      "2 bath",
      "154 sqm"
    ],
    "image": "images (23).jpeg"
  },
  {
    "id": "H-R-211",
    "title": "4-Bedroom Flat, Katampe",
    "location": "Katampe",
    "category": "rent",
    "price": "₦2,872,032",
    "priceNote": "per year",
    "specs": [
      "4 bed",
      "4 bath",
      "177 sqm"
    ],
    "image": "images (24).jpeg"
  },
  {
    "id": "H-R-212",
    "title": "3-Bedroom Duplex, Magodo",
    "location": "Magodo",
    "category": "rent",
    "price": "₦2,596,052",
    "priceNote": "per year",
    "specs": [
      "3 bed",
      "3 bath",
      "159 sqm"
    ],
    "image": "images (25).jpeg"
  },
  {
    "id": "H-R-213",
    "title": "4-Bedroom Bungalow, Kubwa",
    "location": "Kubwa",
    "category": "rent",
    "price": "₦3,223,017",
    "priceNote": "per year",
    "specs": [
      "4 bed",
      "4 bath",
      "152 sqm"
    ],
    "image": "images (26).jpeg"
  },
  {
    "id": "H-R-214",
    "title": "4-Bedroom Terrace, Sangotedo",
    "location": "Sangotedo",
    "category": "rent",
    "price": "₦5,522,620",
    "priceNote": "per year",
    "specs": [
      "4 bed",
      "4 bath",
      "115 sqm"
    ],
    "image": "images (27).jpeg"
  },
  {
    "id": "H-R-215",
    "title": "2-Bedroom Mini Flat, Ogba",
    "location": "Ogba",
    "category": "rent",
    "price": "₦2,087,724",
    "priceNote": "per year",
    "specs": [
      "2 bed",
      "2 bath",
      "36 sqm"
    ],
    "image": "images (28).jpeg"
  },
  {
    "id": "H-S-101",
    "title": "2-Bedroom Bungalow, Ikorodu",
    "location": "Ikorodu",
    "category": "sale",
    "price": "₦41,000,000",
    "priceNote": "asking price",
    "specs": [
      "2 bed",
      "1 bath",
      "188 sqm"
    ],
    "image": "images (29).jpeg"
  },
  {
    "id": "H-S-102",
    "title": "4-Bedroom Detached Duplex, Ikorodu",
    "location": "Ikorodu",
    "category": "sale",
    "price": "₦66,000,000",
    "priceNote": "asking price",
    "specs": [
      "4 bed",
      "4 bath",
      "245 sqm"
    ],
    "image": "images (30).jpeg"
  },
  {
    "id": "H-S-103",
    "title": "4-Bedroom Block of Flats, Banana Island",
    "location": "Banana Island",
    "category": "sale",
    "price": "₦246,000,000",
    "priceNote": "asking price",
    "specs": [
      "4 bed",
      "3 bath",
      "472 sqm"
    ],
    "image": "images (9).jpeg"
  },
  {
    "id": "H-S-104",
    "title": "6-Bedroom Bungalow, Life Camp",
    "location": "Life Camp",
    "category": "sale",
    "price": "₦61,000,000",
    "priceNote": "asking price",
    "specs": [
      "6 bed",
      "6 bath",
      "281 sqm"
    ],
    "image": "images (1).jpeg"
  },
  {
    "id": "H-S-105",
    "title": "4-Bedroom Bungalow, Ikoyi",
    "location": "Ikoyi",
    "category": "sale",
    "price": "₦108,000,000",
    "priceNote": "asking price",
    "specs": [
      "4 bed",
      "3 bath",
      "495 sqm"
    ],
    "image": "images (2).jpeg"
  },
  {
    "id": "H-S-106",
    "title": "6-Bedroom Terrace Duplex, Woji, Port Harcourt",
    "location": "Woji, Port Harcourt",
    "category": "sale",
    "price": "₦59,000,000",
    "priceNote": "asking price",
    "specs": [
      "6 bed",
      "5 bath",
      "512 sqm"
    ],
    "image": "images (3).jpeg"
  },
  {
    "id": "H-S-107",
    "title": "2-Bedroom Terrace Duplex, Gbagada",
    "location": "Gbagada",
    "category": "sale",
    "price": "₦68,000,000",
    "priceNote": "asking price",
    "specs": [
      "2 bed",
      "2 bath",
      "214 sqm"
    ],
    "image": "images (4).jpeg"
  },
  {
    "id": "H-S-108",
    "title": "4-Bedroom Bungalow, Yaba",
    "location": "Yaba",
    "category": "sale",
    "price": "₦73,000,000",
    "priceNote": "asking price",
    "specs": [
      "4 bed",
      "4 bath",
      "486 sqm"
    ],
    "image": "images (5).jpeg"
  },
  {
    "id": "H-S-109",
    "title": "6-Bedroom Bungalow, Katampe",
    "location": "Katampe",
    "category": "sale",
    "price": "₦121,000,000",
    "priceNote": "asking price",
    "specs": [
      "6 bed",
      "6 bath",
      "172 sqm"
    ],
    "image": "images (6).jpeg"
  },
  {
    "id": "H-S-110",
    "title": "2-Bedroom Maisonette, Ikorodu",
    "location": "Ikorodu",
    "category": "sale",
    "price": "₦61,000,000",
    "priceNote": "asking price",
    "specs": [
      "2 bed",
      "1 bath",
      "479 sqm"
    ],
    "image": "images (7).jpeg"
  },
  {
    "id": "H-S-111",
    "title": "4-Bedroom Terrace Duplex, Wuye",
    "location": "Wuye",
    "category": "sale",
    "price": "₦105,000,000",
    "priceNote": "asking price",
    "specs": [
      "4 bed",
      "3 bath",
      "232 sqm"
    ],
    "image": "images (8).jpeg"
  },
  {
    "id": "H-S-112",
    "title": "3-Bedroom Detached Duplex, Bodija, Ibadan",
    "location": "Bodija, Ibadan",
    "category": "sale",
    "price": "₦41,000,000",
    "priceNote": "asking price",
    "specs": [
      "3 bed",
      "3 bath",
      "305 sqm"
    ],
    "image": "images (9).jpeg"
  },
  {
    "id": "H-S-113",
    "title": "2-Bedroom Terrace Duplex, Gwarinpa",
    "location": "Gwarinpa",
    "category": "sale",
    "price": "₦94,000,000",
    "priceNote": "asking price",
    "specs": [
      "2 bed",
      "2 bath",
      "251 sqm"
    ],
    "image": "images (10).jpeg"
  },
  {
    "id": "H-S-114",
    "title": "4-Bedroom Detached Duplex, Nyanya",
    "location": "Nyanya",
    "category": "sale",
    "price": "₦64,000,000",
    "priceNote": "asking price",
    "specs": [
      "4 bed",
      "3 bath",
      "387 sqm"
    ],
    "image": "images.jpeg"
  },
  {
    "id": "H-S-115",
    "title": "2-Bedroom Block of Flats, Bompai, Kano",
    "location": "Bompai, Kano",
    "category": "sale",
    "price": "₦55,000,000",
    "priceNote": "asking price",
    "specs": [
      "2 bed",
      "2 bath",
      "390 sqm"
    ],
    "image": "apartment-lugbe.jpg"
  },
  {
    "id": "L-301",
    "title": "Estate Plot, Kubwa",
    "location": "Kubwa",
    "category": "land",
    "price": "₦9,200,000",
    "priceNote": "per plot",
    "specs": [
      "700 sqm",
      "Cleared land",
      "Excision"
    ],
    "image": "l1.jpeg"
  },
  {
    "id": "L-302",
    "title": "Estate Plot, Nassarawa GRA, Kano",
    "location": "Nassarawa GRA, Kano",
    "category": "land",
    "price": "₦23,100,000",
    "priceNote": "per plot",
    "specs": [
      "1000 sqm",
      "Cleared land",
      "Registered Survey"
    ],
    "image": "l2.jpeg"
  },
  {
    "id": "L-303",
    "title": "Waterfront Plot, Gwarinpa",
    "location": "Gwarinpa",
    "category": "land",
    "price": "₦30,200,000",
    "priceNote": "per plot",
    "specs": [
      "800 sqm",
      "Waterfront",
      "Registered Survey"
    ],
    "image": "l3.jpeg"
  },
  {
    "id": "L-304",
    "title": "Residential Plot, Nyanya",
    "location": "Nyanya",
    "category": "land",
    "price": "₦8,000,000",
    "priceNote": "per plot",
    "specs": [
      "648 sqm",
      "Corner piece",
      "Governor's Consent"
    ],
    "image": "l4.jpeg"
  },
  {
    "id": "L-305",
    "title": "Commercial Plot, Lekki Phase 1",
    "location": "Lekki Phase 1",
    "category": "land",
    "price": "₦90,300,000",
    "priceNote": "per plot",
    "specs": [
      "1000 sqm",
      "Fenced",
      "Gazette"
    ],
    "image": "l5.jpeg"
  },
  {
    "id": "L-306",
    "title": "Waterfront Plot, Ikorodu",
    "location": "Ikorodu",
    "category": "land",
    "price": "₦8,000,000",
    "priceNote": "per plot",
    "specs": [
      "648 sqm",
      "Cleared land",
      "Registered Survey"
    ],
    "image": "l6.jpeg"
  },
  {
    "id": "L-307",
    "title": "Mixed-Use Plot, GRA Phase 2, Port Harcourt",
    "location": "GRA Phase 2, Port Harcourt",
    "category": "land",
    "price": "₦5,400,000",
    "priceNote": "per plot",
    "specs": [
      "1000 sqm",
      "Cleared land",
      "Governor's Consent"
    ],
    "image": "l7.jpeg"
  },
  {
    "id": "L-308",
    "title": "Commercial Plot, Agege",
    "location": "Agege",
    "category": "land",
    "price": "₦25,900,000",
    "priceNote": "per plot",
    "specs": [
      "1200 sqm",
      "Dry land",
      "Excision"
    ],
    "image": "l8.jpeg"
  },
  {
    "id": "L-309",
    "title": "Residential Plot, Nyanya",
    "location": "Nyanya",
    "category": "land",
    "price": "₦13,100,000",
    "priceNote": "per plot",
    "specs": [
      "1000 sqm",
      "Fenced",
      "Excision"
    ],
    "image": "ll.jpeg"
  },
  {
    "id": "L-310",
    "title": "Waterfront Plot, Wuse 2",
    "location": "Wuse 2",
    "category": "land",
    "price": "₦186,400,000",
    "priceNote": "per plot",
    "specs": [
      "800 sqm",
      "Waterfront",
      "Excision"
    ],
    "image": "l6.jpeg"
  },
  {
    "id": "M-401",
    "title": "Lafarge Elephant Cement (50kg)",
    "location": "Warehouse pickup",
    "category": "materials",
    "price": "₦8,700",
    "priceNote": "per bag",
    "specs": [
      "Grade 42.5",
      "In stock"
    ],
    "image": "bua.jpeg"
  },
  {
    "id": "M-402",
    "title": "BUA Cement (50kg)",
    "location": "Ladipo Market",
    "category": "materials",
    "price": "₦8,700",
    "priceNote": "per bag",
    "specs": [
      "Grade 42.5",
      "In stock"
    ],
    "image": "lafa1.jpeg"
  },
  {
    "id": "M-403",
    "title": "Lafarge Elephant Cement (50kg)",
    "location": "Warehouse pickup",
    "category": "materials",
    "price": "₦8,700",
    "priceNote": "per bag",
    "specs": [
      "Grade 42.5",
      "In stock"
    ],
    "image": "lafar.jpeg"
  },
  {
    "id": "M-404",
    "title": "Iron Rod (20mm)",
    "location": "Kirikiri Warehouse",
    "category": "materials",
    "price": "₦22,900",
    "priceNote": "per length",
    "specs": [
      "High tensile",
      "In stock"
    ],
    "image": "i3.jpeg"
  },
  {
    "id": "M-405",
    "title": "Iron Rod (8mm)",
    "location": "Ladipo Market",
    "category": "materials",
    "price": "₦4,500",
    "priceNote": "per length",
    "specs": [
      "High tensile",
      "In stock"
    ],
    "image": "i2.jpeg"
  },
  {
    "id": "M-406",
    "title": "Iron Rod (10mm)",
    "location": "Trade Fair Complex",
    "category": "materials",
    "price": "₦6,800",
    "priceNote": "per length",
    "specs": [
      "High tensile",
      "In stock"
    ],
    "image": "i1.jpeg"
  },
  {
    "id": "M-407",
    "title": "Filling Sand (Tipper load)",
    "location": "Kirikiri Warehouse",
    "category": "materials",
    "price": "₦53,300",
    "priceNote": "per tipper",
    "specs": [
      "Coarse grade",
      "Delivery available"
    ],
    "image": "s3.jpeg"
  },
  {
    "id": "M-408",
    "title": "Sharp Sand (Tipper load)",
    "location": "Ojota Depot",
    "category": "materials",
    "price": "₦62,800",
    "priceNote": "per tipper",
    "specs": [
      "Building grade",
      "Delivery available"
    ],
    "image": "s2.jpeg"
  },
  {
    "id": "M-409",
    "title": "Filling Sand (Tipper load)",
    "location": "Trade Fair Complex",
    "category": "materials",
    "price": "₦44,400",
    "priceNote": "per tipper",
    "specs": [
      "Coarse grade",
      "Delivery available"
    ],
    "image": "s1.jpeg"
  },
  {
    "id": "M-410",
    "title": "Wall Tiles (30x60cm, Glazed)",
    "location": "Ladipo Market",
    "category": "materials",
    "price": "₦4,600",
    "priceNote": "per carton",
    "specs": [
      "Glazed",
      "8 pcs/carton"
    ],
    "image": "t3.jpeg"
  },
  {
    "id": "M-411",
    "title": "Wall Tiles (30x60cm, Glazed)",
    "location": "Ladipo Market",
    "category": "materials",
    "price": "₦3,400",
    "priceNote": "per carton",
    "specs": [
      "Glazed",
      "8 pcs/carton"
    ],
    "image": "t2.jpeg"
  },
  {
    "id": "M-412",
    "title": "Wall Tiles (30x60cm, Glazed)",
    "location": "Ojota Depot",
    "category": "materials",
    "price": "₦4,200",
    "priceNote": "per carton",
    "specs": [
      "Glazed",
      "8 pcs/carton"
    ],
    "image": "t1.jpeg"
  },
  {
    "id": "M-413",
    "title": "Wardrobe (4-Door)",
    "location": "Warehouse pickup",
    "category": "materials",
    "price": "₦237,200",
    "priceNote": "each",
    "specs": [
      "MDF",
      "Mirror panel"
    ],
    "image": "w1.jpeg"
  },
  {
    "id": "M-414",
    "title": "Solid Wood Dining Table (6-Seater)",
    "location": "Kirikiri Warehouse",
    "category": "materials",
    "price": "₦345,300",
    "priceNote": "each",
    "specs": [
      "Solid wood",
      "6 chairs included"
    ],
    "image": "d2.jpeg"
  },
  {
    "id": "M-415",
    "title": "Solid Wood Dining Table (6-Seater)",
    "location": "Ladipo Market",
    "category": "materials",
    "price": "₦188,400",
    "priceNote": "each",
    "specs": [
      "Solid wood",
      "6 chairs included"
    ],
    "image": "d1.jpeg"
  }
];
